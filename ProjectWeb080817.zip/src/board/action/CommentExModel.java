package board.action;

public class CommentExModel {
	
	private int	comment_num;
	private int	comment_board;
	private int comment_commnum;
	private String comment_nick;
	private int	comment_parent;
	private String content;
	private String date;
	
		
	public int getComment_num() {
		return comment_num;
	}
	public void setComment_num(int comment_num) {
		this.comment_num = comment_num;
	}
	public int getComment_board() {
		return comment_board;
	}
	public void setComment_board(int comment_board) {
		this.comment_board = comment_board;
	}
	public int getComment_commnum() {
		return comment_commnum;
	}
	public void setComment_commnum(int comment_commnum) {
		this.comment_commnum = comment_commnum;
	}
	public String getComment_nick() {
		return comment_nick;
	}
	public void setComment_nick(String comment_nick) {
		this.comment_nick = comment_nick;
	}
	public int getComment_parent() {
		return comment_parent;
	}
	public void setComment_parent(int comment_parent) {
		this.comment_parent = comment_parent;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}	
	
	
	
	

}
