package chulcheck.action;

public class ChulCheckModel {
	
	private int	Chul_no;
	private String Chul_id;
	private String Chul_cont;
	private String Chul_date;
	private String Chul_ip;
	private int Chul_day;
	
	
	
	
	
	public int getChul_day() {
		return Chul_day;
	}
	public void setChul_day(int chul_day) {
		Chul_day = chul_day;
	}
	public int getChul_no() {
		return Chul_no;
	}
	public void setChul_no(int chul_no) {
		Chul_no = chul_no;
	}
	public String getChul_id() {
		return Chul_id;
	}
	public void setChul_id(String chul_id) {
		Chul_id = chul_id;
	}
	public String getChul_cont() {
		return Chul_cont;
	}
	public void setChul_cont(String chul_cont) {
		Chul_cont = chul_cont;
	}
	public String getChul_date() {
		return Chul_date;
	}
	public void setChul_date(String chul_date) {
		Chul_date = chul_date;
	}
	public String getChul_ip() {
		return Chul_ip;
	}
	public void setChul_ip(String chul_ip) {
		Chul_ip = chul_ip;
	}
	
	

}
