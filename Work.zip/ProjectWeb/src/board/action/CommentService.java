package board.action;

import java.sql.Connection;
import java.util.ArrayList;

import project.dao.CommentDao;

public class CommentService {
	
	private CommentDao	cmDao = new CommentDao();
	
	
	public ArrayList<CommentModel> read(int num) {
		
		Connection conn = null;
		
		try {
			return cmDao.getComment(num);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		

		return null;		
	}
	
	
	public int write(CommentModel cmt)
	{
		return cmDao.Write(cmt);
	}
	
	public int delete(int num, int bnum)
	{
		return cmDao.DeleteCm(num, bnum);	
	}
	
	public int update(int boardnum, int cmnum, String cont)
	{
		return cmDao.Update(boardnum, cmnum, cont);		
	}

}
