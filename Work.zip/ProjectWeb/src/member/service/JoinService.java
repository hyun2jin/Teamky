package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import jdbc.JdbcUtil;
import jdbc.connection.ConnectionProvider;
import project.dao.*;
import project.model.*;

public class JoinService {

	private MemberDao memberDao = new MemberDao();

	public void join(Member joinReq) {
		Connection conn = null;

		try {
			conn = ConnectionProvider.getConnection();
			conn.setAutoCommit(false);
			
			Member member = memberDao
					.selectById(conn, joinReq.getMem_id());
			if (member != null) {
				JdbcUtil.rollback(conn);
				throw new SQLException();
			}
			
			memberDao.insert(conn, new Member(
					joinReq.getMem_id(),
					joinReq.getMem_nick(),
					joinReq.getMem_pwd(),
					joinReq.getEmail(),
					joinReq.getPhone(),
					joinReq.getMem_st(),
					joinReq.getMem_att()));
			
		
			conn.commit();		

		} catch (Exception e) {
			e.printStackTrace();
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}
	
	
}
