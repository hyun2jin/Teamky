package project.dao;

import java.sql.*;

import jdbc.JdbcUtil;
import project.model.*;


public class MemberDao {
	
	public Member selectById(Connection conn, String id)
			throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn.prepareStatement(
					"SELECT * FROM member where member_id=?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			Member member = null;

			if (rs.next()) {
				member = new Member(
						rs.getInt("member_seq"),
						rs.getString("member_id"),
						rs.getString("member_nick"),
						rs.getString("passwd"),		
						rs.getString("email"),
						rs.getString("phone"),
						rs.getInt("member_st"),
						rs.getInt("member_att"));
			}
			return member;
		} finally {
			JdbcUtil.close(rs, pstmt);
		}
	}

	
	

	public void insert(Connection conn, Member mem)
			throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("INSERT INTO member (member_id, member_nick, passwd, email, phone)"
						+ " VALUES (?, ?, ?, ?, ?) ")) {
			pstmt.setString(1, mem.getMem_id());
			pstmt.setString(2, mem.getMem_nick());
			pstmt.setString(3, mem.getMem_pwd());
			pstmt.setString(4,  mem.getEmail());
			pstmt.setString(5,  mem.getPhone());
			pstmt.executeUpdate();
		}
	}
	
	public void Logout(Connection conn, String nick) {
		
	}

	public void update(Connection conn, Member member)
			throws SQLException {
		String sql = "UPDATE member SET name=?, password=?"
				+ " WHERE memberid=?";
		
		try (PreparedStatement pstmt = conn
				.prepareStatement(sql)) {

			pstmt.setString(1, member.getMem_nick());
			pstmt.setString(2, member.getMem_pwd());
			pstmt.setString(3, member.getMem_id());
			pstmt.executeUpdate();
		}
	}

}
